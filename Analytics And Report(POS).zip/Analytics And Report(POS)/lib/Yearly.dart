import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class Yearly extends StatefulWidget {
  _YearlyState createState()=> _YearlyState();

}
class _YearlyState extends State<Yearly> {
  List<charts.Series<yearlySales, int>> _seriesLineData3;

  _generateData() {
    var linesalesdata2 = [
      new yearlySales(0, 20),
      new yearlySales(1, 24),
      new yearlySales(2, 25),
      new yearlySales(3, 40),
      new yearlySales(4, 45),
      new yearlySales(5, 60),
    ];

    _seriesLineData3.add(
      charts.Series(
        colorFn: (__, _) => charts.ColorUtil.fromDartColor(Color(0xffff9900)),

        data: linesalesdata2,
        domainFn: (yearlySales sales, _) => sales.yearval,
        measureFn: (yearlySales sales, _) => sales.salesval,
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _seriesLineData3 = List<charts.Series<yearlySales, int>>();





    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),

            child: Column(
              children: <Widget>[

                Text(
                  'Sales for the last 5 years',style: TextStyle(fontSize: 16.0,fontWeight: FontWeight.bold),),
                Expanded(
                  child: charts.LineChart(
                      _seriesLineData3,
                      defaultRenderer: new charts.LineRendererConfig(
                          includeArea: true, stacked: true),
                      animate: true,
                      animationDuration: Duration(seconds: 2),
                      behaviors: [
                        new charts.ChartTitle('Years',
                            behaviorPosition: charts.BehaviorPosition.bottom,
                            titleOutsideJustification:charts.OutsideJustification.middleDrawArea),
                        new charts.ChartTitle('Sales',
                            behaviorPosition: charts.BehaviorPosition.start,
                            titleOutsideJustification: charts.OutsideJustification.middleDrawArea),

                      ]
                  ),
                ),
              ],
            ),

      ),

    );
  }
  }

class yearlySales {
  int yearval;
  int salesval;

  yearlySales(this.yearval, this.salesval);
}