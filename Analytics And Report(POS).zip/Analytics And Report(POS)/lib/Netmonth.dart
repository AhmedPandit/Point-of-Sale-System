import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class Netmonth extends StatefulWidget {
  _NetmonthState createState()=> _NetmonthState();

}
class _NetmonthState extends State<Netmonth> {
  List<charts.Series<MonthlyProfit, String>> monthlyBar;

  _generateData() {
    //Data for monthly profit
    var data1 = [
      new MonthlyProfit(2021, 'Jan', 425),
    ];

    var data2 = [
      new MonthlyProfit(2021, 'Feb', 125),
    ];
    var data3 = [
      new MonthlyProfit(2021, 'Mar', 758),
    ];
    var data4 = [
      new MonthlyProfit(2021, 'Apr', 159),
    ];
    var data5 = [
      new MonthlyProfit(2021, 'May', 50),
    ];
    var data6 = [
      new MonthlyProfit(2021, 'Jun', 478),
    ];
    var data7 = [
      new MonthlyProfit(2021, 'Jul', 200),
    ];




    monthlyBar.add(
      charts.Series(
        domainFn: (MonthlyProfit sl, _) => sl.p_Month,
        measureFn: (MonthlyProfit sl, _) => sl.p_quantity,
        id: '2018',
        data: data1,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (MonthlyProfit pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xff990099)),
      ),
    );

    monthlyBar.add(
      charts.Series(
        domainFn: (MonthlyProfit sl, _) => sl.p_Month,
        measureFn: (MonthlyProfit sl, _) => sl.p_quantity,
        id: '2018',
        data: data2,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (MonthlyProfit pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xff109618)),
      ),
    );

    monthlyBar.add(
      charts.Series(
        domainFn: (MonthlyProfit sl, _) => sl.p_Month,
        measureFn: (MonthlyProfit sl, _) => sl.p_quantity,
        id: '2018',
        data: data3,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (MonthlyProfit pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xffff9900)),
      ),
    );

    monthlyBar.add(
      charts.Series(
        domainFn: (MonthlyProfit sl, _) => sl.p_Month,
        measureFn: (MonthlyProfit sl, _) => sl.p_quantity,
        id: '2018',
        data: data4,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (MonthlyProfitpollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.red),
      ),
    );
    monthlyBar.add(
      charts.Series(
        domainFn: (MonthlyProfit sl, _) => sl.p_Month,
        measureFn: (MonthlyProfit sl, _) => sl.p_quantity,
        id: '2018',
        data: data5,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (MonthlyProfit pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.lightBlue),
      ),
    );
    monthlyBar.add(
      charts.Series(
        domainFn: (MonthlyProfit sl, _) => sl.p_Month,
        measureFn: (MonthlyProfit sl, _) => sl.p_quantity,
        id: '2018',
        data: data6,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (MonthlyProfit pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.deepPurple),
      ),
    );
    monthlyBar.add(
      charts.Series(
        domainFn: (MonthlyProfit sl, _) => sl.p_Month,
        measureFn: (MonthlyProfit sl, _) => sl.p_quantity,
        id: '2018',
        data: data7,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (MonthlyProfit pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.deepOrange),
      ),
    );



  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();


    monthlyBar = List<charts.Series<MonthlyProfit, String>>();


    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),

            child: Column(
              children: <Widget>[



                Text(
                  'Net Profit Monthly',
                  style: TextStyle(
                      fontSize: 24.0, fontWeight: FontWeight.bold),
                ),
                Expanded(
                  child: charts.BarChart(
                    monthlyBar,
                    animate: true,
                    barGroupingType: charts.BarGroupingType.grouped,
                    //behaviors: [new charts.SeriesLegend()],
                    animationDuration: Duration(seconds: 2),
                  ),
                ),
              ],
            ),

      ),
    );
  }

}

class MonthlyProfit {
  String p_Month;
  int p_year;
  int p_quantity;

  MonthlyProfit(this.p_year, this.p_Month, this.p_quantity);
}
