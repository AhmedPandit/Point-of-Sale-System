import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class DailySales extends StatefulWidget {
 _DailySalesState createState()=> _DailySalesState();

}
class _DailySalesState extends State<DailySales>{

  List<charts.Series<DailySalesGraph, String>> _seriesBarData1;
  _generateData() {
    //Data for Daily Sales Graph
    var dailydata = [


      new DailySalesGraph('1', 7, 2021, 500),
      new DailySalesGraph('2', 7, 2021, 202),
      new DailySalesGraph('3', 7, 2021, 1000),
      new DailySalesGraph('4', 7, 2021, 200),
      new DailySalesGraph('5', 7, 2021, 300),
      new DailySalesGraph('6', 7, 2021, 0),
      new DailySalesGraph('7', 7, 2021, 333),
      new DailySalesGraph('8', 7, 2021, 567),
      new DailySalesGraph('9', 7, 2021, 212),

    ];

    _seriesBarData1.add(
      charts.Series(
        domainFn: (DailySalesGraph ds, _) => ds.day,
        measureFn: (DailySalesGraph ds, _) => ds.quantity,
        id: '2019',
        data: dailydata,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (DailySalesGraph ds, _) =>
            charts.ColorUtil.fromDartColor(Colors.pinkAccent),
      ),
    );
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _seriesBarData1=List<charts.Series<DailySalesGraph, String>>();


    _generateData();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),



            child: Column(
              children: <Widget>[


                Text(
                  'Sales for each day',style: TextStyle(fontSize: 24.0,fontWeight: FontWeight.bold),),


                Expanded(
                  child: charts.BarChart(
                    _seriesBarData1,
                    animate: true,
                    barGroupingType: charts.BarGroupingType.grouped,
                    //behaviors: [new charts.SeriesLegend()],
                    animationDuration: Duration(seconds: 2),
                  ),
                ),
              ],
            ),

      ),


    );

  }

}
class DailySalesGraph{
  String day;
  int month;
  int year;
  int quantity;
  DailySalesGraph(this.day,this.month,this.year,this.quantity);
}