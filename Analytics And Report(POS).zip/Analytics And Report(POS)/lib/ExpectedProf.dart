import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class ExpectedProf extends StatefulWidget {
  _ExpectedProfState  createState()=> _ExpectedProfState();

}
class _ExpectedProfState extends State<ExpectedProf > {

  List<charts.Series<expectedProfit, String>> expectedPie;


  _generateData() {
// expected profit per item
    var piedata = [
      new expectedProfit('Meat', 300, Color(0xff3366cc)),
      new expectedProfit('Vegetables', 100, Color(0xff991899)),
      new expectedProfit('Rice', 200, Color(0xff109618)),
      new expectedProfit('Spices', 150, Color(0xfffdbe99)),
      new expectedProfit('Sugar', 78, Color(0xffff9900)),
      new expectedProfit('Oil', 40, Color(0xffdc3912)),
    ];

    expectedPie.add(
      charts.Series(
        domainFn: (expectedProfit task, _) => task.p_name,
        measureFn: (expectedProfit task, _) => task.p_profititem,
        colorFn: (expectedProfit task, _) =>
            charts.ColorUtil.fromDartColor(task.p_colorval),
        id: 'Profit per item',
        data: piedata,
        labelAccessorFn: (expectedProfit row, _) => '${row.p_profititem}',
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();


    expectedPie = List<charts.Series<expectedProfit, String>>();

    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),

            child: Column(
              children: <Widget>[



                Text(
                  'Expected Profit in Dollars',
                  style: TextStyle(
                      fontSize: 24.0, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Expanded(
                  child: charts.PieChart(expectedPie,
                      animate: true,
                      animationDuration: Duration(seconds: 2),
                      behaviors: [
                        new charts.DatumLegend(
                          outsideJustification:
                          charts.OutsideJustification.endDrawArea,
                          horizontalFirst: false,
                          desiredMaxRows: 2,
                          cellPadding: new EdgeInsets.only(
                              right: 4.0, bottom: 4.0),
                          entryTextStyle: charts.TextStyleSpec(
                              color: charts
                                  .MaterialPalette.purple.shadeDefault,
                              fontFamily: 'Georgia',
                              fontSize: 11),
                        )
                      ],
                      defaultRenderer: new charts.ArcRendererConfig(
                          arcWidth: 100,
                          arcRendererDecorators: [
                            new charts.ArcLabelDecorator(
                                labelPosition:
                                charts.ArcLabelPosition.inside)
                          ])),
                ),
              ],
            ),

      ),

    );


  }
}




class expectedProfit {
  String p_name;
  double p_profititem;
  Color p_colorval;

  expectedProfit(this.p_name, this.p_profititem, this.p_colorval);
}