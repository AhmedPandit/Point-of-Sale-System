
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class Netyear extends StatefulWidget {
  _NetyearState createState()=> _NetyearState();

}
class _NetyearState extends State<Netyear> {
  List<charts.Series<yearlyProfit, int>> yearLine;

  _generateData() {
    //Data for yearly profit
    var linesalesdata2 = [
      new yearlyProfit(0, 40),
      new yearlyProfit(1, 24),
      new yearlyProfit(2, 50),
      new yearlyProfit(3, 42),
      new yearlyProfit(4, 70),
      new yearlyProfit(5, 20),
    ];

    yearLine.add(
      charts.Series(
        colorFn: (__, _) => charts.ColorUtil.fromDartColor(Color(0xffff9900)),
        data: linesalesdata2,
        domainFn: (yearlyProfit sales, _) => sales.p_year,
        measureFn: (yearlyProfit sales, _) => sales.p_profit,
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();


    yearLine = List<charts.Series<yearlyProfit, int>>();


    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),

            child: Column(
              children: <Widget>[



                Text(
                  'Net profit yearly',
                  style: TextStyle(
                      fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Expanded(
                  child: charts.LineChart(yearLine,
                      defaultRenderer: new charts.LineRendererConfig(
                          includeArea: true, stacked: true),
                      animate: true,
                      animationDuration: Duration(seconds: 2),
                      behaviors: [
                        new charts.ChartTitle('Years',
                            behaviorPosition:
                            charts.BehaviorPosition.bottom,
                            titleOutsideJustification: charts
                                .OutsideJustification.middleDrawArea),
                        new charts.ChartTitle('Sales',
                            behaviorPosition:
                            charts.BehaviorPosition.start,
                            titleOutsideJustification: charts
                                .OutsideJustification.middleDrawArea),
                      ]),
                ),
              ],
            ),

      ),
    );
  }
}

class yearlyProfit {
  int p_year;
  int p_profit;

  yearlyProfit(this.p_year, this.p_profit);
}