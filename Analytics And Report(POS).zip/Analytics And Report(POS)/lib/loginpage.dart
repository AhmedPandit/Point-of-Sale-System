import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutteranimatedchartsapp/Module7page.dart';


class loginpage extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
      PreferredSize(preferredSize: Size.fromHeight(200),child:
      AppBar(
        title: Text("LogIn",style: TextStyle(
          fontSize: 30,
          fontWeight: FontWeight.bold,
        ),),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/background.png"),
                fit: BoxFit.fill
            )
          ),
        ),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomRight: Radius.circular(100),bottomLeft: Radius.circular(100))
        ),


      ),
      ),

      extendBodyBehindAppBar: true,




      body: Container(
        child: Center(
          child: Column(

            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(20),
                child: TextField(
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter your email'
                  ),
                ),
              ),

              Padding(
                  padding: EdgeInsets.all(20),
                child: TextField(
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter Your Password'
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.all(20),
                child: RaisedButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> Module7page())
                  );
                },
                  child: Text("Login",style: TextStyle(color: Colors.white),),
                  color: Colors.deepOrange,


                ),
              )


            ],
          ),
        ),
      ),

    );
  }

}