
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class Profitly extends StatefulWidget {
  _ProfitlyState createState()=> _ProfitlyState();

}
class _ProfitlyState extends State<Profitly> {
  List<charts.Series<Profitperitem, String>> _seriesPieData7;


  _generateData() {
// Data for profit per item
    var piedata = [
      new Profitperitem('Meat', 300, Color(0xff3366cc)),
      new Profitperitem('Vegetables', 100, Color(0xff990099)),
      new Profitperitem('Rice', 200, Color(0xff109618)),
      new Profitperitem('Spices', 150, Color(0xfffdbe19)),
      new Profitperitem('Sugar', 78, Color(0xffff9900)),
      new Profitperitem('Oil', 40, Color(0xffdc3912)),
    ];

    _seriesPieData7.add(
      charts.Series(
        domainFn: (Profitperitem task, _) => task.name,
        measureFn: (Profitperitem task, _) => task.profititem,
        colorFn: (Profitperitem task, _) =>
            charts.ColorUtil.fromDartColor(task.colorval),
        id: 'Profit per item',
        data: piedata,
        labelAccessorFn: (Profitperitem row, _) => '${row.profititem}',
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();


    _seriesPieData7 = List<charts.Series<Profitperitem, String>>();


    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),

            child: Column(
              children: <Widget>[

                Text(
                  'Profit per item In Dollars',style: TextStyle(fontSize: 24.0,fontWeight: FontWeight.bold),),
                SizedBox(height: 10.0,),
                Expanded(
                  child: charts.PieChart(
                      _seriesPieData7,
                      animate: true,
                      animationDuration: Duration(seconds: 2),
                      behaviors: [
                        new charts.DatumLegend(
                          outsideJustification: charts.OutsideJustification.endDrawArea,
                          horizontalFirst: false,
                          desiredMaxRows: 2,
                          cellPadding: new EdgeInsets.only(right: 4.0, bottom: 4.0),
                          entryTextStyle: charts.TextStyleSpec(
                              color: charts.MaterialPalette.purple.shadeDefault,
                              fontFamily: 'Georgia',
                              fontSize: 11),
                        )
                      ],
                      defaultRenderer: new charts.ArcRendererConfig(
                          arcWidth: 100,
                          arcRendererDecorators: [
                            new charts.ArcLabelDecorator(
                                labelPosition: charts.ArcLabelPosition.inside)
                          ])),
                ),
              ],
            ),

      ),
    );
  }
}




class Profitperitem{
  String name;
  double profititem;
  Color colorval;

  Profitperitem(this.name, this.profititem, this.colorval);
}
