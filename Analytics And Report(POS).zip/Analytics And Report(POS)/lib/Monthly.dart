import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class Monthly extends StatefulWidget {
  _MonthlyState createState()=> _MonthlyState();

}
class _MonthlyState extends State<Monthly> {

  List<charts.Series<Monthlysales, String>> _seriesBarData2;

  _generateData() {
    //Data for monthly Sales
    var data1 = [
      new Monthlysales(2021, 'Jan', 150),


    ];

    var data2 = [

      new Monthlysales(2021, 'Feb', 50),


    ];
    var data3 = [
      new Monthlysales(2021, 'Mar', 190),


    ];
    var data4 = [
      new Monthlysales(2021, 'Apr', 300),


    ];
    var data5 = [
      new Monthlysales(2021, 'May', 500),


    ];
    var data6 = [
      new Monthlysales(2021, 'Jun', 400),


    ];
    var data7 = [
      new Monthlysales(2021, 'Jul', 550),


    ];
    var data8 = [
      new Monthlysales(2021, 'Aug', 800),


    ];
    var data9 = [
      new Monthlysales(2021, 'Sept', 666),


    ];
    var data10 = [
      new Monthlysales(2021, 'Oct', 888),


    ];
    var data11 = [
      new Monthlysales(2021, 'Nov', 500),


    ];
    var data12 = [
      new Monthlysales(2021, 'Dec', 1200),


    ];

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data1,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xff990099)),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data2,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xff109618)),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data3,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xffff9900)),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data4,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysalespollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.red),
      ),
    );
    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data5,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.lightBlue),
      ),
    );
    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data6,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.deepPurple),
      ),
    );
    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data7,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.deepOrange),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data8,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.brown),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data9,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.pink),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data10,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.teal),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data11,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.purple.shade800),
      ),
    );

    _seriesBarData2.add(
      charts.Series(
        domainFn: (Monthlysales sl, _) => sl.Month,
        measureFn: (Monthlysales sl, _) => sl.quantity,
        id: '2018',
        data: data12,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Monthlysales pollution, _) =>
            charts.ColorUtil.fromDartColor(Colors.lime[900]),
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();


    _seriesBarData2 = List<charts.Series<Monthlysales, String>>();


    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),

            child: Column(
              children: <Widget>[

                Text(
                  'Monthly Sales (By Quantity)',style: TextStyle(fontSize: 24.0,fontWeight: FontWeight.bold),),
                Expanded(
                  child: charts.BarChart(
                    _seriesBarData2,
                    animate: true,
                    barGroupingType: charts.BarGroupingType.grouped,
                    //behaviors: [new charts.SeriesLegend()],
                    animationDuration: Duration(seconds: 2),
                  ),
                ),
              ],
            ),

      ),


    );

  }
}


class Monthlysales {
  String Month;
  int year;
  int quantity;

  Monthlysales(this.year, this.Month, this.quantity);
}