import 'package:flutter/material.dart';
import 'package:flutteranimatedchartsapp/Module7page.dart';
import 'package:flutteranimatedchartsapp/loginpage.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Analysis and Reports',


      home: loginpage(),
    );
  }
}