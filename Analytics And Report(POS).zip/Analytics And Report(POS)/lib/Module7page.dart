import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutteranimatedchartsapp/DailySales.dart';
import 'package:flutteranimatedchartsapp/ExpectedProf.dart';
import 'package:flutteranimatedchartsapp/Netday.dart';
import 'package:flutteranimatedchartsapp/Netmonth.dart';
import 'package:flutteranimatedchartsapp/Netyear.dart';


import 'DailySales.dart';
import 'Monthly.dart';
import 'Profitly.dart';
import 'Yearly.dart';

class Module7page extends StatelessWidget{
  Widget build (BuildContext context){
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),

        title: Text('Analysis and Reports',),
        centerTitle: true,
      ),

      body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: 40,),

          Center(
            child: Padding(
              padding: EdgeInsets.all(8),
              child:
              ButtonTheme(
                  buttonColor: Colors.deepOrange,
                minWidth: 200,
              child:RaisedButton(onPressed: (){

                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => DailySales()

                  )
                  );


              },
              child: Text("Daily Sales graph",style: TextStyle(color: Colors.white),),)
              ),
            ),
          ),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child:
                ButtonTheme(
                  buttonColor: Colors.deepOrange,
                  minWidth: 200,
                  child:RaisedButton(onPressed: (){
                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => Monthly()

                  )
                  );
                },
                child: Text("Monthly Sales graph",style: TextStyle(color: Colors.white),),),
                ),
              ),
            ),

            Center(

              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child:
                ButtonTheme(
                  buttonColor: Colors.deepOrange,
                  minWidth: 200,
                  child:RaisedButton(onPressed: (){
                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => Yearly()

                  )
                  );
                },
                  child: Text("Yearly Sales graph",style: TextStyle(color: Colors.white),),),
              ),
              ),
            ),

            Center(

              child: Padding(
                padding: const EdgeInsets.all(8.0),

                child:
                ButtonTheme(
                  minWidth: 200,
                  buttonColor: Colors.deepOrange,
                  child:RaisedButton(onPressed: (){
                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => Netday()

                  )
                  );
                },
                  child: Text("Net Profit daily",style: TextStyle(color: Colors.white),),),
              ),
              ),
            ),

            Center(
              child: Padding(

                padding: const EdgeInsets.all(8.0),
                child:ButtonTheme(
                  buttonColor: Colors.deepOrange,
                  minWidth: 200,
                  child: RaisedButton(onPressed: (){
                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => Netmonth()

                  )
                  );
                },
                  child: Text("Net Profit Monthly",style: TextStyle(color: Colors.white),),),
              ),
              ),
            ),

            Center(
              child: Padding(

                padding: const EdgeInsets.all(8.0),
                child:
                ButtonTheme(
                  buttonColor: Colors.deepOrange,
                  minWidth: 200,
                  child:RaisedButton(onPressed: (){
                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => Netyear()

                  )
                  );
                },
                  child: Text("Net Profit Yearly",style: TextStyle(color: Colors.white),),),
                ),
              ),
            ),

            Center(
              child: Padding(

                padding: const EdgeInsets.all(8.0),
                child:

                ButtonTheme(
                  buttonColor: Colors.deepOrange,
                  minWidth: 200,
                  child:RaisedButton(onPressed: (){
                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => Profitly()

                  )
                  );
                },
                  child: Text("Profit Per Item",style: TextStyle(color: Colors.white),),),
              ),
              ),
            ),

            Center(
              child:
              Padding(

                padding: const EdgeInsets.all(8.0),
                child: ButtonTheme(
                  buttonColor: Colors.deepOrange,
                  minWidth: 200,
                  child:RaisedButton(onPressed: (){
                  Navigator.push(
                      context, new MaterialPageRoute(
                      builder: (context) => ExpectedProf()

                  )
                  );
                },
                  child: Text("Expected Profit",style: TextStyle(color: Colors.white),),),
              ),
              ),
            ),

        ],
      ),
    );
  }
}