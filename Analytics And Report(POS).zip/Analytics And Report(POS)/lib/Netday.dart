import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Module7page.dart';

class Netday extends StatefulWidget {
  _NetdayState createState()=> _NetdayState();

}
class _NetdayState extends State<Netday> {

  List<charts.Series<DailyProfit, String>> dailyBar;

  _generateData() {
    //Data for Daily profit
    var dailydata = [
      new DailyProfit('1', 4, 2021, 200),
      new DailyProfit('2', 4, 2021, 502),
      new DailyProfit('3', 4, 2021, 100),
      new DailyProfit('4', 4, 2021, 900),
      new DailyProfit('5', 4, 2021, 100),
      new DailyProfit('6', 4, 2021, 125),
      new DailyProfit('7', 4, 2021, 52),
      new DailyProfit('8', 4, 2021, 957),
      new DailyProfit('9', 4, 2021, 912),
    ];

    dailyBar.add(
      charts.Series(
        domainFn: (DailyProfit ds, _) => ds.p_day,
        measureFn: (DailyProfit ds, _) => ds.p_quantity,
        id: '2019',
        data: dailydata,
        fillPatternFn: (_, __) => charts.FillPatternType.forwardHatch,
        fillColorFn: (DailyProfit ds, _) =>
            charts.ColorUtil.fromDartColor(Colors.pinkAccent),
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    dailyBar = List<charts.Series<DailyProfit, String>>();


    _generateData();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.orange[600],
        //backgroundColor: Color(0xff308e1c),



        title: Text('Analysis and Reports',),
        centerTitle: true,

      ),
      body:

      Padding(
        padding: EdgeInsets.all(8.0),


            child: Column(
              children: <Widget>[

                Text(
                  'Net Profit daily',
                  style: TextStyle(
                      fontSize: 24.0, fontWeight: FontWeight.bold),
                ),
                Expanded(
                  child: charts.BarChart(
                    dailyBar,
                    animate: true,
                    barGroupingType: charts.BarGroupingType.grouped,
                    //behaviors: [new charts.SeriesLegend()],
                    animationDuration: Duration(seconds: 2),
                  ),
                ),
              ],
            ),


      ),
    );
}
}

class DailyProfit {
  String p_day;
  int p_month;
  int p_year;
  int p_quantity;
  DailyProfit(this.p_day, this.p_month, this.p_year, this.p_quantity);
}