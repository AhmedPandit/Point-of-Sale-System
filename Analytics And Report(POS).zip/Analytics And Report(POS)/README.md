# flutteranimatedchartsapp

Flutter Tutorial - Flutter Animated Charts
Flutter Tutorial - Flutter Animated Charts Video series can be watched here https://www.youtube.com/watch?v=GwDMwnELTP4

## Getting Started

We will see how to add animated charts in your flutter application using charts_flutter plugin.
 
For more details regarding Flutter charts with Staggered Grid view check this link - https://www.youtube.com/watch?v=4gkt5qDBq4w

For more details about charts_flutter Plugin check this link - https://pub.dartlang.org/packages/charts_flutter#-readme-tab-

The online gallery link - https://google.github.io/charts/flutter/gallery.html

https://flutter.dev/docs/development/packages-and-plugins/androidx-compatibility
https://github.com/flutter/flutter/issues/15972 

<div style="text-align: center">
    <table>
        <tr>
            <td style="text-align: center">
                    <img src="https://github.com/whatsupcoders/FlutterAnimatedCharts/blob/master/assets/Screenshot_1559363591.png" width="200"/>
            </td>            
            <td style="text-align: center">              
                      <img src="https://github.com/whatsupcoders/FlutterAnimatedCharts/blob/master/assets/Screenshot_1559363135.png" width="200"/>
            </td>
            <td style="text-align: center">
                     <img src="https://github.com/whatsupcoders/FlutterAnimatedCharts/blob/master/assets/Screenshot_1559363122.png" width="200"/>
            </td>
            <td style="text-align: center">
                     <img src="https://github.com/whatsupcoders/FlutterAnimatedCharts/blob/master/assets/animatedcharts.gif" width="200"/>
            </td>            
      </tr>
  </table>
  </div>
  
For more Flutter Tutorials watch my videos on https://www.youtube.com/c/whatsupcoders <br />
If you appreciate the content 📖, support projects visibility, give 👍| ⭐| 👏

FOLLOW ME HERE:

Facebook: https://www.facebook.com/whatsupcoders <br />
Twitter: https://www.twitter.com/whatsupcoders
